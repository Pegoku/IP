#include <stdio.h>

int main() {
    char nom[50];
    scanf("%s",nom);
    printf("Hola %s",nom);
    return 0;
}