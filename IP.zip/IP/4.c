#include <stdio.h>

int main() {
    int num;
    scanf("%d",&num);
    printf("%d",num*num);
    return 0;
}