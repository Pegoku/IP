#include <stdio.h>

int main() {
    int num;
    char lletra;

    scanf("%c %d", &lletra, &num);
    printf("%d\n%c", num, lletra);

    return 0;
}