#include <stdio.h>


int main() {
    char c[128], d[128];
    scanf("%s %s", c, d);
    printf("%s %s\n", d, c);
    return 0;
}