#include <stdio.h>

int main() {
    int nombre;
    printf("Introdueix un nombre: ");
    scanf("%d", &nombre);
    printf("%d", nombre);
    return 0;
}