#include <stdio.h>

int main()
{
    for (int i = 2; i <= 100; i+=2)
    {
        printf("%d ", i);
    }

    return 0;
}