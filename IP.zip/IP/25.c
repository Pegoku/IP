#include <stdio.h>

int main() {
    char l;
    scanf("%c", &l);
    if (l == 'a'){
        printf("Es una a");
    } else{
        printf("No es una a");
    }
    return 0;
}