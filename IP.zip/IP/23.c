#include <stdio.h>

int main()
{
    int n,m;
    scanf("%d",&n);
    scanf("%d",&m);
    double s = (double)n / (double)m;
    printf ("%f" , s);
    return 0;
}
